﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace RazorPagesIgnis.Migrations.RazorPagesIgnisIdentityDb
{
    public partial class CreateIdentitySchema : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
